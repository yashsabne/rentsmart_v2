const { SOCKET_EVENTS } = require("../constants/events");
const Conversation = require("../models/Conversation");
const Message = require("../models/Message");
const { logMessageReceived } = require("../services/activityService");

// Track online users: Map<publicId, socketId>
const onlineUsers = new Map();

/**
 * Registers all Socket.IO event handlers.
 * Called once per connected socket after auth middleware passes.
 */
const registerChatHandlers = (io, socket) => {
  const user = socket.user; // attached by socketAuth middleware
  const userPublicId = user.publicId;
  const userId = user._id || user.id;

  // Mark user as online
  onlineUsers.set(userPublicId, socket.id);

  // Broadcast online status to all connected sockets
  io.emit(SOCKET_EVENTS.USER_ONLINE, { publicId: userPublicId });

  console.log(`[socket] User connected: ${userPublicId} (${socket.id})`);

  // ─── JOIN CONVERSATION ROOM ───────────────────────────────────────────────
  socket.on(SOCKET_EVENTS.JOIN_CONVERSATION, async ({ conversationSlug }) => {
    try {
      // Verify user is a participant before allowing room join
      const conversation = await Conversation.findOne({ conversationSlug });

      if (!conversation) {
        return socket.emit(SOCKET_EVENTS.ERROR, {
          message: "Conversation not found.",
        });
      }

      const isParticipant = conversation.participants.some(
        (p) => p.userId.toString() === userId.toString()
      );

      if (!isParticipant) {
        return socket.emit(SOCKET_EVENTS.ERROR, {
          message: "Access denied to this conversation.",
        });
      }

      socket.join(conversationSlug);
      console.log(`[socket] ${userPublicId} joined room: ${conversationSlug}`);

      // Mark delivered: any messages the user hasn't received yet
      await Message.updateMany(
        {
          conversationId: conversation._id,
          senderPublicId: { $ne: userPublicId },
          status: "sent",
        },
        { $set: { status: "delivered" } }
      );

      // Notify the sender that messages were delivered
      io.to(conversationSlug).emit(SOCKET_EVENTS.MESSAGE_DELIVERED, {
        conversationSlug,
        deliveredTo: userPublicId,
      });
    } catch (err) {
      console.error("[socket joinConversation] Error:", err);
      socket.emit(SOCKET_EVENTS.ERROR, { message: "Failed to join conversation." });
    }
  });

  // ─── LEAVE CONVERSATION ROOM ─────────────────────────────────────────────
  socket.on(SOCKET_EVENTS.LEAVE_CONVERSATION, ({ conversationSlug }) => {
    socket.leave(conversationSlug);
    console.log(`[socket] ${userPublicId} left room: ${conversationSlug}`);
  });

  // ─── SEND MESSAGE (real-time relay) ──────────────────────────────────────
  // NOTE: This is for real-time delivery only.
  // The actual persistence happens via REST POST /messages/send.
  // Frontend calls REST first, then emits this event to notify the other user.
  socket.on(
    SOCKET_EVENTS.SEND_MESSAGE,
    async ({ conversationSlug, messageData }) => {
      try {
        const conversation = await Conversation.findOne({ conversationSlug });

        if (!conversation) return;

        const isParticipant = conversation.participants.some(
          (p) => p.userId.toString() === userId.toString()
        );

        if (!isParticipant) return;

        // Relay encrypted message to all room members (including sender for confirmation)
        io.to(conversationSlug).emit(SOCKET_EVENTS.RECEIVE_MESSAGE, {
          conversationSlug,
          message: messageData, // already encrypted — server never decrypts
        });

        // Log activity for the recipient
        const recipient = conversation.participants.find(
          (p) => p.publicId !== userPublicId
        );

        if (recipient) {
          logMessageReceived(recipient.userId, conversationSlug);
        }
      } catch (err) {
        console.error("[socket sendMessage] Error:", err);
      }
    }
  );

  // ─── TYPING INDICATORS ───────────────────────────────────────────────────
  socket.on(SOCKET_EVENTS.TYPING, ({ conversationSlug }) => {
    // Broadcast to others in room (not sender)
    socket.to(conversationSlug).emit(SOCKET_EVENTS.TYPING, {
      conversationSlug,
      publicId: userPublicId,
    });
  });

  socket.on(SOCKET_EVENTS.STOP_TYPING, ({ conversationSlug }) => {
    socket.to(conversationSlug).emit(SOCKET_EVENTS.STOP_TYPING, {
      conversationSlug,
      publicId: userPublicId,
    });
  });

  // ─── MESSAGE READ ─────────────────────────────────────────────────────────
  socket.on(SOCKET_EVENTS.MESSAGE_READ, async ({ conversationSlug }) => {
    try {
      // Broadcast read receipt to room
      io.to(conversationSlug).emit(SOCKET_EVENTS.MESSAGE_READ, {
        conversationSlug,
        readBy: userPublicId,
        readAt: new Date().toISOString(),
      });
    } catch (err) {
      console.error("[socket messageRead] Error:", err);
    }
  });

  // ─── DISCONNECT ──────────────────────────────────────────────────────────
  socket.on(SOCKET_EVENTS.DISCONNECT, () => {
    onlineUsers.delete(userPublicId);
    io.emit(SOCKET_EVENTS.USER_OFFLINE, { publicId: userPublicId });
    console.log(`[socket] User disconnected: ${userPublicId}`);
  });
};

/**
 * Returns whether a user is currently online.
 */
const isUserOnline = (publicId) => onlineUsers.has(publicId);

/**
 * Returns the set of all online public IDs.
 */
const getOnlineUsers = () => Array.from(onlineUsers.keys());

module.exports = { registerChatHandlers, isUserOnline, getOnlineUsers };