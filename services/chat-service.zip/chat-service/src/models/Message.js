const mongoose = require("mongoose");

const messageSchema = new mongoose.Schema(
  {
    // Reference to parent conversation
    conversationId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Conversation",
      required: true,
      index: true,
    },

    // Public ID of sender — never a raw Mongo ID
    senderPublicId: {
      type: String,
      required: true,
      // e.g. "USR-9DK3P8"
    },

    // AES-GCM encrypted message content — NEVER plaintext
    ciphertext: {
      type: String,
      required: true,
    },

    // Initialization vector for AES-GCM — required for decryption
    iv: {
      type: String,
      required: true,
    },

    // Delivery/read tracking
    status: {
      type: String,
      enum: ["sent", "delivered", "read"],
      default: "sent",
    },

    // When the recipient read the message
    readAt: {
      type: Date,
      default: null,
    },
  },
  { timestamps: true }
);

// Index for paginated message loading per conversation
messageSchema.index({ conversationId: 1, createdAt: -1 });

module.exports = mongoose.model("Message", messageSchema);