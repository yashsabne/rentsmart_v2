const mongoose = require("mongoose");

// Participant sub-schema — stores public profile, never exposes raw Mongo ID to frontend
const participantSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      // Never sent to frontend — used internally for auth checks
    },
    publicId: {
      type: String,
      required: true,
      // e.g. "USR-9DK3P8" — this is what frontend sees
    },
    fullName: { type: String, required: true },
    email: { type: String, required: true },
    avatar: { type: String, default: "" },
    role: {
      type: String,
      enum: ["buyer", "owner"],
      required: true,
    },
  },
  { _id: false }
);

const conversationSchema = new mongoose.Schema(
  {
    // Human-readable slug used in URLs — never a Mongo ID
    conversationSlug: {
      type: String,
      required: true,
      unique: true,
      index: true,
    },

    // Property snapshot stored at conversation creation time
    propertyId: { type: String, required: true },
    propertyTitle: { type: String, required: true },
    propertyImage: { type: String, default: "" },
    propertyLocation: { type: String, default: "" },
    propertyPrice: { type: String, default: "" },

    // Two participants: buyer and owner
    participants: {
      type: [participantSchema],
      validate: {
        validator: (arr) => arr.length === 2,
        message: "A conversation must have exactly 2 participants.",
      },
    },

    // Used for sorting conversation list
    lastMessageAt: { type: Date, default: Date.now },

    // Encrypted preview of last message (ciphertext) — never plaintext
    lastMessagePreviewEncrypted: { type: String, default: "" },
    lastMessageIv: { type: String, default: "" },

    // Whether either participant has archived this conversation
    archivedBy: [{ type: mongoose.Schema.Types.ObjectId }],

    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

// Compound index: quickly check if conversation exists for buyer+owner+property
conversationSchema.index({ propertyId: 1, "participants.userId": 1 });

module.exports = mongoose.model("Conversation", conversationSchema);