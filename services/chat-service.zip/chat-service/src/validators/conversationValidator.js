const { body } = require("express-validator");

// ─── startConversation ────────────────────────────────────────────────────────
// Validates POST /conversations/start
const startConversationValidator = [
  body("propertyId")
    .notEmpty().withMessage("propertyId is required")
    .isMongoId().withMessage("propertyId must be a valid Mongo ID"),

  body("propertyTitle")
    .notEmpty().withMessage("propertyTitle is required")
    .isString().trim(),

  body("propertyImage")
    .optional()
    .isURL().withMessage("propertyImage must be a valid URL"),

  body("propertyLocation")
    .optional()
    .isString().trim(),

  body("propertyPrice")
    .optional()
    .isNumeric().withMessage("propertyPrice must be a number"),

  // Owner info — provided by client from property details page
  body("ownerId")
    .notEmpty().withMessage("ownerId is required")
    .isMongoId().withMessage("ownerId must be a valid Mongo ID"),

  body("ownerPublicId")
    .notEmpty().withMessage("ownerPublicId is required"),

  body("ownerName")
    .notEmpty().withMessage("ownerName is required"),

  body("ownerEmail")
    .notEmpty().withMessage("ownerEmail is required")
    .isEmail().withMessage("ownerEmail must be a valid email"),

  // First message (encrypted)
  body("ciphertext")
    .notEmpty().withMessage("ciphertext is required"),

  body("iv")
    .notEmpty().withMessage("iv is required"),
];

module.exports = { startConversationValidator };
