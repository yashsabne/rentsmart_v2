const { body, param } = require("express-validator");

// Validation rules for starting a new conversation
const validateStartConversation = [
  body("propertyId").notEmpty().withMessage("propertyId is required."),
  body("propertyTitle").notEmpty().withMessage("propertyTitle is required."),
  body("propertyImage").optional().isString(),
  body("propertyLocation").optional().isString(),
  body("propertyPrice").optional().isString(),

  // Owner details (the property owner)
  body("owner.userId").notEmpty().withMessage("owner.userId is required."),
  body("owner.publicId").notEmpty().withMessage("owner.publicId is required."),
  body("owner.fullName").notEmpty().withMessage("owner.fullName is required."),
  body("owner.email").isEmail().withMessage("owner.email must be valid."),

  // First message — must be encrypted
  body("ciphertext").notEmpty().withMessage("ciphertext is required."),
  body("iv").notEmpty().withMessage("iv is required."),
];

// Validation rules for sending a message
const validateSendMessage = [
  body("conversationSlug")
    .notEmpty()
    .withMessage("conversationSlug is required."),
  body("ciphertext").notEmpty().withMessage("ciphertext is required."),
  body("iv").notEmpty().withMessage("iv is required."),
];

// Validation for slug param
const validateSlugParam = [
  param("slug")
    .notEmpty()
    .matches(/^chat-rs-[a-z0-9]+$/)
    .withMessage("Invalid conversation slug format."),
];

module.exports = {
  validateStartConversation,
  validateSendMessage,
  validateSlugParam,
};