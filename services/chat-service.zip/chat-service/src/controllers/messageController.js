const { validationResult } = require("express-validator");
const Message = require("../models/Message");
const Conversation = require("../models/Conversation");
const { logMessageSent, logMessageRead } = require("../services/activityService");

const PAGE_SIZE = 30; // Messages per page for infinite scroll

/**
 * POST /messages/send
 * Stores an encrypted message. Backend only ever sees ciphertext + iv.
 */
const sendMessage = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const { conversationSlug, ciphertext, iv } = req.body;
    const userId = req.user._id || req.user.id;
    const senderPublicId = req.user.publicId;

    // Find conversation and verify participant
    const conversation = await Conversation.findOne({ conversationSlug });

    if (!conversation) {
      return res.status(404).json({ message: "Conversation not found." });
    }

    const isParticipant = conversation.participants.some(
      (p) => p.userId.toString() === userId.toString()
    );

    if (!isParticipant) {
      return res.status(403).json({ message: "Access denied." });
    }

    // Save message — only encrypted content stored
    const message = await Message.create({
      conversationId: conversation._id,
      senderPublicId,
      ciphertext,
      iv,
      status: "sent",
    });

    // Update conversation's last message preview (still encrypted)
    conversation.lastMessageAt = new Date();
    conversation.lastMessagePreviewEncrypted = ciphertext;
    conversation.lastMessageIv = iv;
    await conversation.save();

    logMessageSent(userId, conversationSlug);

    // Return the saved message (without internal conversationId ObjectId)
    return res.status(201).json({
      message: {
        _id: message._id,
        senderPublicId: message.senderPublicId,
        ciphertext: message.ciphertext,
        iv: message.iv,
        status: message.status,
        createdAt: message.createdAt,
      },
    });
  } catch (error) {
    console.error("[sendMessage] Error:", error);
    return res.status(500).json({ message: "Failed to send message." });
  }
};

/**
 * GET /messages/:slug
 * Returns paginated messages for a conversation (oldest-first for chat UX).
 * Supports infinite scroll via ?before=messageId query param.
 */
const getMessages = async (req, res) => {
  try {
    const { slug } = req.params;
    const { before } = req.query; // for infinite scroll — load messages before this ID
    const userId = req.user._id || req.user.id;

    const conversation = await Conversation.findOne({
      conversationSlug: slug,
    });

    if (!conversation) {
      return res.status(404).json({ message: "Conversation not found." });
    }

    const isParticipant = conversation.participants.some(
      (p) => p.userId.toString() === userId.toString()
    );

    if (!isParticipant) {
      return res.status(403).json({ message: "Access denied." });
    }

    // Build query — optionally paginate before a cursor
    const query = { conversationId: conversation._id };
    if (before) {
      query._id = { $lt: before };
    }

    const messages = await Message.find(query)
      .sort({ createdAt: -1 }) // newest first from DB
      .limit(PAGE_SIZE)
      .lean();

    // Reverse for chronological display
    const chronological = messages.reverse();

    // Strip internal conversationId from response
    const safe = chronological.map((m) => ({
      _id: m._id,
      senderPublicId: m.senderPublicId,
      ciphertext: m.ciphertext,
      iv: m.iv,
      status: m.status,
      readAt: m.readAt,
      createdAt: m.createdAt,
    }));

    return res.status(200).json({
      messages: safe,
      hasMore: messages.length === PAGE_SIZE,
    });
  } catch (error) {
    console.error("[getMessages] Error:", error);
    return res.status(500).json({ message: "Failed to fetch messages." });
  }
};

/**
 * PATCH /messages/read
 * Marks all unread messages in a conversation as read for the authenticated user.
 */
const markMessagesRead = async (req, res) => {
  try {
    const { conversationSlug } = req.body;
    const userId = req.user._id || req.user.id;
    const userPublicId = req.user.publicId;

    const conversation = await Conversation.findOne({ conversationSlug });

    if (!conversation) {
      return res.status(404).json({ message: "Conversation not found." });
    }

    const isParticipant = conversation.participants.some(
      (p) => p.userId.toString() === userId.toString()
    );

    if (!isParticipant) {
      return res.status(403).json({ message: "Access denied." });
    }

    // Mark all messages NOT sent by the current user as read
    const result = await Message.updateMany(
      {
        conversationId: conversation._id,
        senderPublicId: { $ne: userPublicId }, // messages from the other person
        status: { $ne: "read" },
      },
      {
        $set: {
          status: "read",
          readAt: new Date(),
        },
      }
    );

    logMessageRead(userId, conversationSlug);

    return res.status(200).json({
      updated: result.modifiedCount,
    });
  } catch (error) {
    console.error("[markMessagesRead] Error:", error);
    return res.status(500).json({ message: "Failed to mark messages read." });
  }
};

module.exports = { sendMessage, getMessages, markMessagesRead };