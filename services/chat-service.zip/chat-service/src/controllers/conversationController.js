const { validationResult } = require("express-validator");
const Conversation = require("../models/Conversation");
const Message = require("../models/Message");
const { generateConversationSlug } = require("../utils/slugGenerator");
const {
  logChatStarted,
  logMessageSent,
} = require("../services/activityService");

/**
 * POST /conversations/start
 * Creates a new conversation OR reuses existing one for same buyer+owner+property.
 * Also stores the first message (encrypted).
 */
const startConversation = async (req, res) => {
  // Validate request body
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const {
      propertyId,
      propertyTitle,
      propertyImage,
      propertyLocation,
      propertyPrice,
      owner, // { userId, publicId, fullName, email, avatar }
      ciphertext,
      iv,
    } = req.body;

    // Buyer is the authenticated user making the request
    const buyerUserId = req.user.id || req.user.id;
    const buyerPublicId = req.user.id;
    const buyerFullName = req.user.fullName || req.user.name;
    const buyerEmail = req.user.email;
    const buyerAvatar = req.user.avatar || "";

    // Check if a conversation already exists for this buyer+owner+property combo
    const existing = await Conversation.findOne({
      propertyId,
      "participants.userId": { $all: [buyerUserId, owner.userId] },
    });

    if (existing) {
      // Reuse existing conversation — just add the new message
      const newMessage = await Message.create({
        conversationId: existing._id,
        senderPublicId: buyerPublicId,
        ciphertext,
        iv,
        status: "sent",
      });

      // Update last message preview (encrypted)
      existing.lastMessageAt = new Date();
      existing.lastMessagePreviewEncrypted = ciphertext;
      existing.lastMessageIv = iv;
      await existing.save();

      logMessageSent(buyerUserId, existing.conversationSlug);

      return res.status(200).json({
        conversationSlug: existing.conversationSlug,
        isNew: false,
        messageId: newMessage._id,
      });
    }

    // Create new conversation
    const conversationSlug = generateConversationSlug();

    const conversation = await Conversation.create({
      conversationSlug,
      propertyId,
      propertyTitle,
      propertyImage: propertyImage || "",
      propertyLocation: propertyLocation || "",
      propertyPrice: propertyPrice || "",
      participants: [
        {
          userId: buyerUserId,
          publicId: buyerPublicId,
          fullName: buyerFullName,
          email: buyerEmail,
          avatar: buyerAvatar,
          role: "buyer",
        },
        {
          userId: owner.userId,
          publicId: owner.userId,
          fullName: owner.fullName,
          email: owner.email,
          avatar: owner.avatar || "",
          role: "owner",
        },
      ],
      lastMessageAt: new Date(),
      lastMessagePreviewEncrypted: ciphertext,
      lastMessageIv: iv,
    });

    // Store first message
    const firstMessage = await Message.create({
      conversationId: conversation._id,
      senderPublicId: buyerPublicId,
      ciphertext,
      iv,
      status: "sent",
    });

    // Log to activity service
    logChatStarted(buyerUserId, conversationSlug, propertyId);
    logMessageSent(buyerUserId, conversationSlug);

    return res.status(201).json({
      conversationSlug,
      isNew: true,
      messageId: firstMessage._id,
    });
  } catch (error) {
    console.error("[startConversation] Error:", error);
    return res.status(500).json({ message: "Failed to start conversation." });
  }
};

/**
 * GET /conversations
 * Returns all conversations for the authenticated user.
 * Excludes raw Mongo IDs from response.
 */
const getConversations = async (req, res) => {
  try {
    const userId = req.user.id || req.user.id;

    const conversations = await Conversation.find({
      "participants.userId": userId,
      isActive: true,
    })
      .sort({ lastMessageAt: -1 })
      .lean();

    // Strip internal Mongo IDs — only expose safe fields
    const safe = conversations.map((c) => ({
      conversationSlug: c.conversationSlug,
      propertyId: c.propertyId,
      propertyTitle: c.propertyTitle,
      propertyImage: c.propertyImage,
      propertyLocation: c.propertyLocation,
      propertyPrice: c.propertyPrice,
      participants: c.participants.map((p) => ({
        publicId: p.publicId,
        fullName: p.fullName,
        email: p.email,
        avatar: p.avatar,
        role: p.role,
      })),
      lastMessageAt: c.lastMessageAt,
      lastMessagePreviewEncrypted: c.lastMessagePreviewEncrypted,
      lastMessageIv: c.lastMessageIv,
      isArchived: c.archivedBy?.some(
        (id) => id.toString() === userId.toString()
      ),
      createdAt: c.createdAt,
    }));

    return res.status(200).json({ conversations: safe });
  } catch (error) {
    console.error("[getConversations] Error:", error);
    return res.status(500).json({ message: "Failed to fetch conversations." });
  }
};

/**
 * GET /conversations/:slug
 * Returns a single conversation by slug.
 */
const getConversationBySlug = async (req, res) => {
  try {
    const { slug } = req.params;
    const userId = req.user.id || req.user.id;

    const conversation = await Conversation.findOne({
      conversationSlug: slug,
    }).lean();

    if (!conversation) {
      return res.status(404).json({ message: "Conversation not found." });
    }

    // Security: only participants can view
    const isParticipant = conversation.participants.some(
      (p) => p.userId.toString() === userId.toString()
    );

    if (!isParticipant) {
      return res.status(403).json({ message: "Access denied." });
    }

    // Strip Mongo IDs
    const safe = {
      conversationSlug: conversation.conversationSlug,
      propertyId: conversation.propertyId,
      propertyTitle: conversation.propertyTitle,
      propertyImage: conversation.propertyImage,
      propertyLocation: conversation.propertyLocation,
      propertyPrice: conversation.propertyPrice,
      participants: conversation.participants.map((p) => ({
        publicId: p.publicId,
        fullName: p.fullName,
        email: p.email,
        avatar: p.avatar,
        role: p.role,
      })),
      lastMessageAt: conversation.lastMessageAt,
      createdAt: conversation.createdAt,
    };

    return res.status(200).json({ conversation: safe });
  } catch (error) {
    console.error("[getConversationBySlug] Error:", error);
    return res.status(500).json({ message: "Failed to fetch conversation." });
  }
};

/**
 * PATCH /conversations/archive/:slug
 * Soft-archives a conversation for the requesting user only.
 */
const archiveConversation = async (req, res) => {
  try {
    const { slug } = req.params;
    const userId = req.user.id || req.user.id;

    const conversation = await Conversation.findOne({
      conversationSlug: slug,
    });

    if (!conversation) {
      return res.status(404).json({ message: "Conversation not found." });
    }

    const isParticipant = conversation.participants.some(
      (p) => p.userId.toString() === userId.toString()
    );

    if (!isParticipant) {
      return res.status(403).json({ message: "Access denied." });
    }

    // Add userId to archivedBy array if not already there
    if (!conversation.archivedBy.includes(userId)) {
      conversation.archivedBy.push(userId);
      await conversation.save();
    }

    return res.status(200).json({ message: "Conversation archived." });
  } catch (error) {
    console.error("[archiveConversation] Error:", error);
    return res.status(500).json({ message: "Failed to archive conversation." });
  }
};

module.exports = {
  startConversation,
  getConversations,
  getConversationBySlug,
  archiveConversation,
};