const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const {
  startConversation,
  getConversations,
  getConversationBySlug,
  archiveConversation,
} = require("../controllers/conversationController");
const {
  validateStartConversation,
  validateSlugParam,
} = require("../validators/messageValidator");

// POST /conversations/start — create or reuse conversation + send first message
router.post("/start", protect, validateStartConversation, startConversation);

// GET /conversations — list all conversations for authenticated user
router.get("/", protect, getConversations);

// GET /conversations/:slug — get single conversation details
router.get("/:slug", protect, validateSlugParam, getConversationBySlug);

// PATCH /conversations/archive/:slug — archive conversation for current user
router.patch("/archive/:slug", protect, validateSlugParam, archiveConversation);

module.exports = router;