const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const {
  sendMessage,
  getMessages,
  markMessagesRead,
} = require("../controllers/messageController");
const {
  validateSendMessage,
  validateSlugParam,
} = require("../validators/messageValidator");

// POST /messages/send — send an encrypted message
router.post("/send", protect, validateSendMessage, sendMessage);

// GET /messages/:slug — get paginated messages for a conversation
router.get("/:slug", protect, validateSlugParam, getMessages);

// PATCH /messages/read — mark messages as read
router.patch("/read", protect, markMessagesRead);

module.exports = router;